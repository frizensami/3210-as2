#ifndef HELPER_H
#define HELPER_H

/***********************************************************
  Helper functions
***********************************************************/

//For exiting on error condition
void die(int lineNo);

//For trackinng execution
long long wallClockTime();

#endif
